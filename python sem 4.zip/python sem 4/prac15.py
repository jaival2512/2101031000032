# #method_1
def reverse_v1(x):
  y = x.split()
  result = []
  for word in y:
    result.insert(0,word)
  return " ".join(result)
test1 = input("Enter a sentence: ")
print (reverse_v1(test1))


# method_2
def reverse_v2(x):
  y = x.split()
  return " ".join(y[::-1])
test1 = input("Enter a sentence: ")
print (reverse_v2(test1))


# # method_3
def reverse_v3(x):
  y = x.split()
  return " ".join(reversed(y))
test1 = input("Enter a sentence: ")
print (reverse_v3(test1))