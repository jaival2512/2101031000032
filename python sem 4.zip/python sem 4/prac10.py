import random

rd = random.randint(1,10)
guess,count=0,0

while guess != rd:
    guess = input("Enter any number between 1 to 10\n")

    if guess=='exit':
        break

    count+=1
    guess=int(guess)
    if guess>rd:
        print("Guess is Too High...\n")
    elif guess<rd:
        print("Guess is Too Low...\n")
    else:
        print("You Guessed Right !!!\n")
        print(f"You took {count} guesses.")
