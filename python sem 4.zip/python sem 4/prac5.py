list=[]
print("enter your number")
num=int(input())
for i in range(1,num+1):
    if(num%i==0):
        print(i)
        list.append(i)
print(list)