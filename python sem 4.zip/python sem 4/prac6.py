a=[1,2,3,4,5,6,7,8,9,10,1,2,3,5,5,55,66,56,89]
b=[1,2,3,45,66,7,88,99,98,66,3,2,4,5,6,8,9]
c=[]
for i in a:
    if i in b and i not in c: #using identifiers to get common elements in two the list
        c.append(i)
print(c)