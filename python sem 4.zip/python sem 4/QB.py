# # QB Q-41
# string = "Silver Oak University"
# for letter in string:
#     if letter not in ['e', 's']:
#         print(letter, end='')

# # #QB Q-48
# for i in range(20):
#    if i%2==0:
#        print(i)

# # #QB Q-46
# for i in range(1, 11):
#     print(i)

# # # QB Q-31
# r=float(input("Enter Radius"))
# area=3.14*r*r
# print(area)

# # # QB Q-32
# a=float(input("Enter length"))
# b=float(input("Enter breath"))
# perimeter=2*(a+b)
# print(perimeter)

# # # QB Q-52
# n = int(input("Enter a number: "))

# if n < 2:
#     print(n, "is not a prime number")
# else:
#     prime = True
#     for i in range(2, n):
#         if n % i == 0:
#             prime = False
#             break

#     if prime:
#         print(n, "is a prime number")
#     else:
#         print(n, "is not a prime number")


# # #Qb Q-62
# def sum(n):
#     if n == 1:
#         return 1
#     else:
#         return n + sum(n - 1)

# print(sum(5))

# # # QB Q-54(a)
# def evenodd(n):
#      if n%2==0:
#         print('even')
#      else:
#         print('odd')
# print(evenodd(10))

# # # QB Q-54(b)
def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n - 1)

for i in range(1, 11):
    print(factorial(i))

# # # QB Q-53
# n=int(input("Enter number:"))
# temp=n
# rev=0
# while(n>0):
#     dig=n%10
#     rev=rev*10+dig
#     n=n//10
# if(temp==rev):
#     print("The number is a palindrome!")
# else:
#     print("The number isn't a palindrome!")
    
# # Print 10 elements using for loop.
# for i in range(1,11):
#     print(i)
