def rmv(duplicate):
	list = []
	for num in duplicate:
		if num not in list:
			list.append(num)
	return list
	
duplicate = [2, 4, 10, 20, 5, 2, 20, 4]
print(rmv(duplicate))



