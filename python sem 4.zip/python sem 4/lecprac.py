# char=input("enter character")
# if(char=='a' or char=='e' or char=='i' or  char=='o' or char=='u'):
#     print("the entered character is vowel")
# else:
#     print("the entered character is consonant")     


# thisdict1={
#     "fruit":"apple"
# }
# thisdict2={
#     "cricketer":"MS dhoni"
# }
# thisdict3={

# }
# thisdict3=thisdict1.join(thisdict2)
# print(thisdict3)



# Python code to merge dict using update() method
# def Merge(dict1, dict2):
# 	return(dict2.update(dict1))

# dict1 = {'fruit':'apple', 'vegetable':'cabbage'}
# dict2 = {'batsman':'rohit sharma', 'wicketkeeper':'MS Dhoni'}
# dict3=dict2.update(dict1)

# print(merge )
# print(dict3)


alist=[3,67,"cat",3.14,False]

print(len(alist))