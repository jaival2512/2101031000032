<?php
    $a = 10;
    $b = 5;

    echo "value of a is: ",$a;
    echo "<br>";
    echo "value of b is: ",$b;
    echo "<br>";
    echo "addition of 2 numbers is: ",$a+$b;
    echo "<br>";
    echo "substraction of 2 numbers is: ",$a-$b;
    echo "<br>";
    echo "multiplication of 2 numbers is: ",$a*$b;
    echo "<br>";
    echo "division of 2 numbers is: ",$a/$b;
    echo "<br>";
?>