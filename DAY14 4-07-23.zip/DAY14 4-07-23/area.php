<?php
    $r=5;
    $pi=3.14;
    $a=$pi*$r*$r;
    echo "area of circle is: ", $a;

    echo "<br>";
    echo "<br>";

    $l = 10;
    $b = 10;
    $z = $l*$b;
    echo "area of rectangle is: ",$z;
?>