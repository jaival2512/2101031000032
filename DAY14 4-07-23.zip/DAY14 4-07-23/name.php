<?php
    $name = "jaival choksi";
    $dept = "Information Technology";
    $enroll = 2101031000032;

    echo $name;
    echo "<br>";
    echo $dept;
    echo "<br>";
    echo $enroll;
    echo "<br>"; 
?>