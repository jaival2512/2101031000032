<?php
    echo "while loop";
    $x = 1;

    while($x <= 5) {
      echo "The number is: $x <br>";
      $x++;
    }

    echo "do while loop";
    $x = 1;

do {
  echo "The number is: $x <br>";
  $x++;
} while ($x <= 5);

echo "for loop";
for ($x = 0; $x <= 10; $x++) {
    echo "The number is: $x <br>";
  }

  echo "for each loop";
  $colors = array("red", "green", "blue", "yellow");

  foreach ($colors as $value) {
    echo "$value <br>";
  }
?>