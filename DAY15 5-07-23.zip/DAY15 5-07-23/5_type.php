<?php
    $a="123.abc";
    echo "type of a is: ".gettype($a)."<br>";

    settype($a,"int");
    echo "after convertion type of a is: ".gettype($a)."<br>";

    echo $a;
?>