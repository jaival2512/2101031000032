<?php
    echo "while loop";
    $x = 0;
    $a = 2;
      echo "table of 2 is"; 
    while($x <= 10) {
      echo $a."*".$x."=".$a*$x. "<br>";
      $x++;
    }
?>