<?php
$a = 20;
$b = 10;
$operator = $check['operator'];
$CalculatorResult = '';

switch ($operator) {
case "Sum":
$CalculatorResult = $a + $b;
break;
case "Subtraction":
 $CalculatorResult = $a - $b;
break;
case "Multiplication":
$CalculatorResult = $a * $b;
break;
case "Division":
$CalculatorResult = $a / $b;
}
?> 