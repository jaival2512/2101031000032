<?php
    $a = 10;
    $b = 5;

    $add=$a+$b;
    $sub=$a-$b;
    $mul=$a*$b;
    $div=$a/$b;

    echo "value of a is: ",$a;
    echo "<br>";
    echo "value of b is: ",$b;
    echo "<br>";
    echo "addition of 2 numbers is: ",$add;
    echo "<br>";
    echo "substraction of 2 numbers is: ",$sub;
    echo "<br>";
    echo "multiplication of 2 numbers is: ",$mul;
    echo "<br>";
    echo "division of 2 numbers is: ",$div;
    echo "<br>";
?>