<?php
    $a = 15;
    $b = 45;

    // echo ($a>$b)?("<br>" .$a. "is greater"):("<br>" .$b. "is greater");

    // if ( $a > $b ){
    //     echo $a."is greater";
    // }
    // else{
    //     echo $b."is greater";
    // }

    $a = 10;
    $b = 15;
    $c = 20;
 if ( $a > $b ){
    
    if ( $a > $c ){
    
        echo $a."is greater";
    }
    else{
        echo $c."is greater";
    }
}
else{
    if ( $b > $c ){
    
        echo $b."is greater";
    }
    else{
        echo $c."is greater";
    }
}
?>
