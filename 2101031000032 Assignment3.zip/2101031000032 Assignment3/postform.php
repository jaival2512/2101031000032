<?php
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $email=$_POST['email'];
    $contact=$_POST['contact'];
    $feedback=$_POST['msg'];
    

    $username = "root";
    $servername = "localhost";
    $password = "";
    $dbname ="formdata"; 

    $conn = mysqli_connect($servername,$username,$password,$dbname);
    if(!$conn){
        echo "connection failed";
    }
    // else{
    //     echo "connection successfull";
    // }
    $sql = "INSERT INTO dataform(FirstName,LastName,Email,contact,Feedback)VALUES('$fname','$lname','$email','$contact','$feedback')";
    if(mysqli_query($conn,$sql)){
        echo"Value inserted";
    }
    else{
        echo "error";
    }

?>