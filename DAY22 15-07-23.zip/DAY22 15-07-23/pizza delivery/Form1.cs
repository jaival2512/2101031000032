﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void panel4_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void checkBox3_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            //Pizza Type Selection Fn1353

            if (radioButton1.Checked == true)
            {
                if (radioButton5.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Normal Crust Small Pizza");
                    item.SubItems.Add("1");
                    item.SubItems.Add("4.00");
                    listView1.Items.Add(item);

                }
                else if (radioButton6.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Cheesy Crust Small Pizza");
                    item.SubItems.Add("1");
                    item.SubItems.Add("4.00");
                    listView1.Items.Add(item);

                }
                else if (radioButton7.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Sausage Crust Small Pizza");
                    item.SubItems.Add("1");
                    item.SubItems.Add("4.00");
                    listView1.Items.Add(item);

                }

            }

            else if (radioButton2.Checked == true)
            {
                if (radioButton5.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Normal Crust Medium Pizza");
                    item.SubItems.Add("1");
                    item.SubItems.Add("7.00");
                    listView1.Items.Add(item);

                }
                else if (radioButton6.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Cheesy Crust Medium Pizza");
                    item.SubItems.Add("1");
                    item.SubItems.Add("7.00");
                    listView1.Items.Add(item);

                }
                else if (radioButton7.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Sausage Crust Medium Pizza");
                    item.SubItems.Add("1");
                    item.SubItems.Add("7.00");
                    listView1.Items.Add(item);

                }
            }

            else if (radioButton3.Checked == true)
            {
                if (radioButton5.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Normal Crust Large Pizza");
                    item.SubItems.Add("1");
                    item.SubItems.Add("10.00");
                    listView1.Items.Add(item);

                }
                else if (radioButton6.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Cheesy Crust Large Pizza");
                    item.SubItems.Add("1");
                    item.SubItems.Add("10.00");
                    listView1.Items.Add(item);

                }
                else if (radioButton7.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Sausage Crust Large Pizza");
                    item.SubItems.Add("1");
                    item.SubItems.Add("10.00");
                    listView1.Items.Add(item);

                }
            }

            else if (radioButton4.Checked == true)
            {
                if (radioButton5.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Normal Crust Extra Large Pizza");
                    item.SubItems.Add("1");
                    item.SubItems.Add("13.00");
                    listView1.Items.Add(item);

                }
                else if (radioButton6.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Cheesy Crust Extra Large Pizza");
                    item.SubItems.Add("1");
                    item.SubItems.Add("13.00");
                    listView1.Items.Add(item);

                }
                else if (radioButton7.Checked == true)
                {
                    ListViewItem item = new ListViewItem("Sausage Crust Extra Large Pizza");
                    item.SubItems.Add("1");
                    item.SubItems.Add("13.00");
                    listView1.Items.Add(item);

                }
            }


            //Pizza Topping Selection

            if (checkBox19.Checked == true)
            {
                ListViewItem item = new ListViewItem("Chesse");
                item.SubItems.Add("");
                item.SubItems.Add("0.75");
                listView1.Items.Add(item);

            }

            if (checkBox17.Checked == true)
            {
                ListViewItem item = new ListViewItem("Paneer");
                item.SubItems.Add("");
                item.SubItems.Add("0.75");
                listView1.Items.Add(item);

            }

            if (checkBox16.Checked == true)
            {
                ListViewItem item = new ListViewItem("Corn");
                item.SubItems.Add("");
                item.SubItems.Add("0.75");
                listView1.Items.Add(item);

            }

            if (checkBox15.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Jalepeno");
                item.SubItems.Add("");
                item.SubItems.Add("0.75");
                listView1.Items.Add(item);

            }

            if (checkBox18.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Pineapple");
                item.SubItems.Add("");
                item.SubItems.Add("0.75");
                listView1.Items.Add(item);

            }

            if (checkBox8.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Kheema");
                item.SubItems.Add("");
                item.SubItems.Add("0.75");
                listView1.Items.Add(item);

            }

            if (checkBox10.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Chicken");
                item.SubItems.Add("");
                item.SubItems.Add("0.75");
                listView1.Items.Add(item);

            }

            if (checkBox6.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Pork");
                item.SubItems.Add("");
                item.SubItems.Add("0.75");
                listView1.Items.Add(item);

            }
            if (checkBox7.Checked == true)
            {
                ListViewItem item = new ListViewItem("  Anchovies Toppings");
                item.SubItems.Add("");
                item.SubItems.Add("0.75");
                listView1.Items.Add(item);

            }

            //Drink Selection

            if (checkBox12.Checked == true)
            {
                ListViewItem item = new ListViewItem("Sprite");
                item.SubItems.Add(textBox20.Text);
                int qty = Convert.ToInt32(textBox20.Text);
                double cost = qty * 20;
                string dCost = cost.ToString();
                item.SubItems.Add(dCost);
                listView1.Items.Add(item);

            }

            else
            {
                textBox20.Text = "";
            }

            if (checkBox1.Checked == true)
            {
                ListViewItem item = new ListViewItem("Fanta");
                item.SubItems.Add(textBox19.Text);
                int qty = Convert.ToInt32(textBox19.Text);
                double cost = qty * 20;
                string dCost = cost.ToString();
                item.SubItems.Add(dCost);
                listView1.Items.Add(item);

            }

            else
            {
                textBox19.Text = "";
            }

            if (checkBox2.Checked == true)
            {
                ListViewItem item = new ListViewItem("Diet Coke");
                item.SubItems.Add(textBox18.Text);
                int qty = Convert.ToInt32(textBox18.Text);
                double cost = qty * 20;
                string dCost = cost.ToString();
                item.SubItems.Add(dCost);
                listView1.Items.Add(item);

            }

            else
            {
                textBox18.Text = "";
            }

            if (checkBox20.Checked == true)
            {
                ListViewItem item = new ListViewItem("Limbu Sharbat");
                item.SubItems.Add(textBox17.Text);
                int qty = Convert.ToInt32(textBox17.Text);
                double cost = qty * 20;
                string dCost = cost.ToString();
                item.SubItems.Add(dCost);
                listView1.Items.Add(item);
            }

            else
            {
                textBox17.Text = "";
            }

            if (checkBox22.Checked == true)
            {
                ListViewItem item = new ListViewItem("Beer");
                item.SubItems.Add(textBox16.Text);
                int qty = Convert.ToInt32(textBox16.Text);
                double cost = qty * 20;
                string dCost = cost.ToString();
                item.SubItems.Add(dCost);
                listView1.Items.Add(item);
            }

            else
            {
                textBox16.Text = "";
            }

            if (checkBox9.Checked == true)
            {
                ListViewItem item = new ListViewItem("wine");
                item.SubItems.Add(textBox15.Text);
                int qty = Convert.ToInt32(textBox15.Text);
                double cost = qty * 20;
                string dCost = cost.ToString();
                item.SubItems.Add(dCost);
                listView1.Items.Add(item);
            }

            else
            {
                textBox15.Text = "";
            }

            //Other Items Selection

            if (checkBox5.Checked == true)
            {
                ListViewItem item = new ListViewItem("Fry Frenchy");
                item.SubItems.Add("");
                item.SubItems.Add("20.0");
                listView1.Items.Add(item);

            }

            if (checkBox4.Checked == true)
            {
                ListViewItem item = new ListViewItem("Garlic Bread");
                item.SubItems.Add("");
                item.SubItems.Add("20.0");
                listView1.Items.Add(item);

            }

            if (checkBox3.Checked == true)
            {
                ListViewItem item = new ListViewItem("Paneer BBQ");
                item.SubItems.Add("");
                item.SubItems.Add("20.0");
                listView1.Items.Add(item);

            }

            if (checkBox11.Checked == true)
            {
                ListViewItem item = new ListViewItem("Nachos");
                item.SubItems.Add("");
                item.SubItems.Add("20.0");
                listView1.Items.Add(item);

            }

            if (checkBox13.Checked == true)
            {
                ListViewItem item = new ListViewItem("Taco");
                item.SubItems.Add("");
                item.SubItems.Add("20.0");
                listView1.Items.Add(item);

            }


            if (checkBox14.Checked == true)
            {
                ListViewItem item = new ListViewItem("Samosa");
                item.SubItems.Add("");
                item.SubItems.Add("20.0");
                listView1.Items.Add(item);

            }
            double total = 0;
            double gst = 0;
            double totaldue = 0;

            foreach (ListViewItem item in listView1.Items)
            {
                total += Convert.ToDouble(item.SubItems[2].Text);
            }

            gst = total * 0.18;
            totaldue = gst + total;

            string gstDisplay = gst.ToString("c2");
            string totalDisplay = totaldue.ToString("c2");
            string amount = total.ToString("c2");

            textBox8.Text = amount;
            textBox1.Text = gstDisplay;
            textBox2.Text = totalDisplay;

            tabControl1.SelectTab("tabPage2");
        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab("tabPage1");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            textBox8.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab("tabPage3");
            textBox19.Text = textBox2.Text;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab("tabPage2");
        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    
}
