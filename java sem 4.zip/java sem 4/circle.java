

class circle 
{
   
        double radius;
        circle()
        {
            radius=25;
        }
            circle(double newradius)
        {
            radius = newradius;
        }
        void getperimeter()
        {
            double area= 2*radius*3.14;
            System.out.println("the perimeter of circle is:"+area);
        }
    
    
}

class testcircle
{
    public static void main(String[] args) 
    {
       circle c1=new circle();
       c1.getperimeter();
       
       circle c2=new circle(100);
       c2.getperimeter();
    }
}