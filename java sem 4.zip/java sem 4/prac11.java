import java.util.*;
class palindrome
{
    public static void main(String[] args)
    {
        int r,sum=0,temp;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter number");
        int n=sc.nextInt();
        temp=n;    
        while(n>0)
        {    
            r=n%10;  //getting remainder  
            sum=(sum*10)+r;    
            n=n/10;
        } 
        if(temp==sum)
        {
            System.out.println("entered number is palindrome");
        
        }
        else
        {
            System.out.println("entered number is not palindrome");
        }
    }    
}
