// import java.util.*;
// class a
// {
//     void hello()
//     {
//         System.out.println("HELLO JAVA");
//     }
// }

// class b extends a
// {
//     void hello()
//     // {
//         System.out.println("this is dynamic method disspatch");
//     }
// }

// class prac17
// {
//     public static void main(String[] args) 
//     {
//         a obj1=new b();
//         obj1.hello();
//         a obj2=new c();
//         obj2.hello();
//     }
// }


// // A Java program to illustrate Dynamic Method
// // Dispatch using hierarchical inheritance
// // import java.util.*;

// // import javax.sound.sampled.SourceDataLine;
// // class A
// // {
// // 	void m1()
// // 	{
// // 		System.out.println("Inside A's m1 method");
// // 	}
// // }

// // class B extends A
// // {
// // 	// overriding m1()
// // 	void m1()
// // 	{
// // 		System.out.println("Inside B's m1 method");
// // 	}
// // }

// // class C extends A
// // {
// // 	void m1()
// // 	{
// // 		System.out.println("Inside C's m1 method");
// // 	}
// // }

// // class Dispatch
// // {
// // 	public static void main(String args[])
// // 	{
// // 		A a = new A();
// //         B b = new B();
// // 		C c = new C();
// // 		A ref;
// // 		ref = a;
// // 		ref.m1();
// // 		ref = b;
// // 		ref.m1();
// // 		ref = c;
// // 		ref.m1();
// // 	}
// // }


class A
{
	int x = 10;
}
class B extends A
{
	int x = 20;
}
class Test
{
	public static void main(String args[])
	{
		A a = new B(); 
		System.out.println(a.x);
	}
}

