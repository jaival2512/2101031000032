class a
{
    void helloa()
    {
        System.out.println("hello world class a");
    }
}
class b extends a
{
    void hellob()
    {
        System.out.println("hello world class b");
    }
}
class c extends b
{
    void helloc()
    {
        System.out.println("hello world class c");
    }
}

class MLI
{
    public static void main(String[] args)
    {
       c obj=new c() ;
       obj.helloc();
       obj.helloa();
       obj.hellob();
    } 
}