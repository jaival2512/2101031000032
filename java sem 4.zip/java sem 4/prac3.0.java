// class hello
// {
//     public static void main(String[] args)
//     {
//         System.out.println("hello java");
//     }
// }



import java.util.*;
class simplfy
{
    public static void main(String[] args)
    {
        float sum,average,percentage;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter value of a");
        float a=sc.nextFloat();
        System.out.println("enter value of b");
        float b=sc.nextFloat();
        System.out.println("enter value of c");
        float c=sc.nextFloat();
        System.out.println("enter value of d");
        float d=sc.nextFloat();
        System.out.println("enter value of e");
        float e=sc.nextFloat();
        System.out.println("enter value of f");
        float f=sc.nextFloat();
        sum=a+b+c+d+e+f;
        average=sum/6;
        percentage=(sum*100)/600;
        System.out.println(sum);
        System.out.println(average);
        System.out.println(percentage);
    }
}