// QB Q-15
// class ArrayAverage 
// { 
//     public static void main(String[] args) 
//     {
//         int[] array = { 1, 2, 3, 4, 5};
//         int length = array.length;
//         int sum = 0;
//         for (int i = 0; i < array.length; i++) 
//         {
//             sum += array[i];
//         }
//         double average = sum / length; 
//         System.out.println("Average of array : "+average);
 
//     }
 
// }




// class StringBufferExample
// {  
//     public static void main(String args[])
//     {  
//         StringBuffer sb=new StringBuffer("Hello ");     
//         sb=sb.append("Java");//now original string is changed  
//         System.out.println(sb);//prints Hello Java
//     }  
// }

// QB Q-23
class Fibonacci{  
    static int n1=0,n2=1,n3=0;    
    static void printFibonacci(int count){    
       if(count>0){    
            n3 = n1 + n2;    
            n1 = n2;    
            n2 = n3;
            System.out.print(" "+n3);   
            printFibonacci(count-1);    
        }    
    }    
    public static void main(String args[]){    
     int count=10;    
     System.out.print(n1+" "+n2);    
     printFibonacci(count-2); 
    }  
   }

// // QB Q-16
// class matrix
// {  
//     public static void main(String args[])
//     {    
//         int a[][]={{1,1,1},{2,2,2},{3,3,3}};    
//         int b[][]={{1,1,1},{2,2,2},{3,3,3}};
//         int c[][]=new int[3][3];   
//         for(int i=0;i<3;i++)
//         {    
//             for(int j=0;j<3;j++)
//             {    
//                 c[i][j]=0;      
//                 for(int k=0;k<3;k++)      
//                 {      
//                     c[i][j]+=a[i][k]*b[k][j];      
//                 }  
//                 System.out.print(c[i][j]+" ");
//             }
//             System.out.println();    
//         }    
//     }
// } 

// area of circle using constructor
// import java.util.Scanner;
// class Area
// {
// 	double area;
// 	Area(Float r)
// 	{
// 	 area= 3.14*r*r;

// 	}
// }
// class AreaOfCircle 
// {
//    public static void main(String args[]) 
//     {   
//       Scanner sc= new Scanner(System.in);
//       System.out.println("Enter the radius:");
//       float r= sc.nextFloat();      
//       Area  a=new Area(r);
//       System.out.println("Area of Circle is: " + a.area);      
//    }
//  }