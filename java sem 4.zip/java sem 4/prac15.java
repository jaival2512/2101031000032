class rectanglebox
{
    double h,w,l,a;
    double recvol,cubevol;
    rectanglebox()
    {
        l=5;
        w=10;
        h=20;
    }
    rectanglebox(double x)
    {
        a=x;
    }
    void rec()
    {
        recvol=l*h*w;
        System.out.println("volume of rectangle is"+recvol);
    }
    void cube()
    {
        cubevol=a*a*a;
        System.out.println("volume of cube is"+cubevol);
    }
}
class volume
{
    public static void main(String[] args)
    {
        rectanglebox r1=new rectanglebox(5);
        r1.cube();
        

        rectanglebox r2=new rectanglebox();

        r2.rec();
    }
}