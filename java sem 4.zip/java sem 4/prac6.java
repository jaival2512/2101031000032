import java.util.*;
class count
{
    public static void main(String[] args)
    {
        char c;
        int up=0;
        Scanner sc=new Scanner(System.in);
        String s=new String();
        System.out.println("enter the string");
        s=sc.nextLine();
        for(int i=0;i<s.length();i++)
        {
            c=s.charAt(i);
            if(c>=65 && c<=90)
            {
                up++;
            }
        }
        System.out.println("total capital letters are"+up);
    }    
}
