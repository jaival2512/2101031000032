// import java.util.*;
// class a
// {
//     public static void main(String[] args)
//     {
//         System.out.println("Enter a string");
//         Scanner sc= new Scanner(System.in);  
//     }
// }


// // QB Q-10
// import java.util.*;
// class marks
// {
//     public static void main(String[] args)
//     {
//         int sum,percent;
//         Scanner sc=new Scanner(System.in);
//         System.out.println("enter marks of oopu");
//         int a=sc.nextInt();
//         System.out.println("enter marks of pp");
//         int b=sc.nextInt();
//         System.out.println("enter marks of os");
//         int c=sc.nextInt();
//         System.out.println("enter marks of camp");
//         int d=sc.nextInt();
//         System.out.println("enter marks of dsgt");
//         int e=sc.nextInt();
//         sum=a+b+c+d+e;
//         System.out.println("sum is:"+sum);
//         percent=(sum*100)/500;
//         System.out.println("pertcentage is:"+percent);
//         if(percent>=90)
//         {
//             System.out.println("distinction");
//         }
//         else if(percent<=89 && percent>=70)
//         {
//             System.out.println("first class");
//         }
//         else if(percent<=69 && percent>=33)
//         {
//             System.out.println("Second Class");
//         }
//         else
//         {
//             System.out.println("fail");
//         }
//     }
// }

// Qb Q-15
class average
{
    public static void main(String[] args)
    {
        int sum;
        int [] arr={1,2,3,4,5};
        sum=0;
        for (int i = 0; i < arr.length; i++)
        {
            sum +=arr[i];
        }
        float average=sum/arr.length;
        System.out.println("the average of 5 interger is:"+average);

    }
}