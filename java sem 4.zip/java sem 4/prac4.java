// import java.util.*;
// class simplify
// {
// 	public static void main(String[] args)
// 	{
// 		float x,y;
// 		Scanner sc= new Scanner(System.in); 
// 		System.out.println("enter value of a");
// 		float a=sc.nextFloat();

// 		System.out.println("enter value of b");
// 		float b=sc.nextFloat();

// 		System.out.println("enter value of c");
// 		float c=sc.nextFloat();
  
// 		System.out.println("enter value of d");
// 		float d=sc.nextFloat();

// 		System.out.println("enter value of e");
// 		float e=sc.nextFloat();

// 		System.out.println("enter value of f");
// 		float f=sc.nextFloat();
		
// 		x=((e*d-b*f)/(a*d-b*c));
// 		System.out.println("the value of x is"+x);
// 		y=((a*f-e*c)/(a*d-b*c));
// 		System.out.println("the value of y is"+y);				
// 	}
// }


import java.util.*;

import javax.xml.transform.Source;
class marksheet
{
	public static void main(String[] args) 
	{
		float sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter value");
		float a=sc.nextFloat();
		System.out.println("enter value");
		float b=sc.nextFloat();
		sum=a+b;
		System.out.println("the total is"+sum);	
	}
}