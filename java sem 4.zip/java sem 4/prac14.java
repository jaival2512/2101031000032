// import java.util.Scanner;
// class FindArea{
//     double radius , length , width;
//     double cirArea , recArea;
//     final double PI = 3.14;

//     // Area of circle
//     double area(double r){
//         cirArea = PI*r*r;
//         return cirArea;
//     }

//     // Area of Rectangle 
//     double area(double l , double w){
//         recArea = l*w;
//         return recArea;
//     }
// }
// public class prac14 {
//     public static void main(String[] args) {
//         FindArea a = new FindArea();
//         Scanner sc = new Scanner(System.in);

//         //  Circle
//         System.out.println("Enter radius of circle : ");
//         double radius = sc.nextDouble();

//         double circle = a.area(radius);

//         System.out.println("Area of Circle : " + circle);

//         // Rectangle
//         System.out.println("Enter length of Rectangle : ");
//         double length = sc.nextDouble();

//         System.out.println("Enter width of Rectangle : ");
//         double width = sc.nextDouble();

        
//         double rectangle = a.area(length , width);

        
//         System.out.println("Area of Rectangle : " + rectangle);
//     }
// }


