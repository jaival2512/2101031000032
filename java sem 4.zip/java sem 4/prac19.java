// arithmetic exception
class prac19 
{
	public static void main(String[] args)
	{
		int a = 5;
		int b = 0;
		try
        {
			System.out.println(a / b); 
		}
		catch (ArithmeticException e) 
        {
			System.out.println(e);
		}
	}
}

// array index out of bound execption
// class exception_handling
// {
// 	public static void main(String[] args)
// 	{
// 		try
// 		{
// 			int a[]=new int[5];
// 			a[6]=9;
// 		}
// 		catch(ArrayIndexOutOfBoundsException e)
// 		{
// 			System.out.println(e);
// 		}
// 	}
// }


