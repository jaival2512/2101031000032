import java.util.*;
import java.util.Scanner;

class LoginPage 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        String username = "jaival";
        String password = "jaival2512";

        System.out.println("||| Login Page |||");

        System.out.print("Enter username: ");
        String inputUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        String inputPassword = scanner.nextLine();

        if (inputUsername.equals(username) && inputPassword.equals(password)) 
        {
            System.out.println("Login successful!");
        } 
        else 
        {
            System.out.println("Invalid username or password.");
        }

        scanner.close();
    }
}
// 