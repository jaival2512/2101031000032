import java.util.random.*;
class numplate 
{
    
}
