import java.util.*;
class pattern
{
   public static void main(String[] args)
   {
	char ch[]={'j','a','i','v','a','l'};
	String s=new String(ch);
	int i,j,k,n;
	n=s.length();
	for(i=n;i>0;i--)
	{
	        j=0;
			
		for(k=i;k<=n;k++)
		{
			
			System.out.print(ch[j]);
			System.out.print(" ");
			j++;
		}
		System.out.println("");
		
	}	
   }
}
