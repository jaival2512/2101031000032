import java.util.*;
class SubString
{
    public static void main(String[] args)
    {
        // Scanner sc=new Scanner(System.in);

        // String s=new String();
        String str="jaival choksi";
        // System.out.println("Enter a String :");
        // s=sc.next();
        int l=str.length();
        System.out.println("Length of the string "+str+" is "+l);
        System.out.println("Your sub String is:"+str.substring(l/2));
    }
}
