import java.util.*;
class avgnew
{
    public static void main(String[] args)
    {
        float sum,percentage,avg;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter value a");
        float a=sc.nextFloat();
        System.out.println("enter value b");
        float b=sc.nextFloat();
        System.out.println("enter value c");
        float c=sc.nextFloat();
        System.out.println("enter value d");
        float d=sc.nextFloat();
        System.out.println("enter value e");
        float e=sc.nextFloat();
        System.out.println("enter value f");
        float f=sc.nextFloat();
        sum=a+b+c+d+e+f;
        System.out.println("the sum of 6 subjects is"+sum);
        avg=sum/6;
        System.out.println("the average of 6 subjects is"+avg);
        percentage=(sum*100)/600;
        System.out.println("the percentage of 6 subjects is"+percentage);
        
    }
}
