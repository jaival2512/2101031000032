import java.util.*;
class meter
{
    public static void main(String[] args)
    {
        float feet;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter meters");
        float a=sc.nextFloat();
        feet=a*3;
        System.out.println("meters to feet is"+feet);
    }
}
