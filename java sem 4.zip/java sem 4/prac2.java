import java.util.*;
class dollar
{
    public static void main(String[] args)
    {
        float b;
       Scanner sc=new Scanner(System.in);
       System.out.println("enter value inr");
       float a=sc.nextFloat();
       b=a/70;
       System.out.println("the inr of dollar is"+b);

    }
}
