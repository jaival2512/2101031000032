import java.util.*;
class vowelscons
{
    public static void main(String[] args)
    {
        int i=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("enter character");
        char ch=sc.next().charAt(0);
        if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' || ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U')
        { 
            System.out.println("entered character is vowel");
        }
        else
        {
            System.out.println("enter character is consonant");
        }

    }    
}
