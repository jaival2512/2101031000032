# list=[11,2,4,5,1,3,10,9]
# list2=[]
# for i in list:
#     if i<5:
#         print(i)
#         list2.append(i)
# print(list2)


#using code optimization
list=[1,2,3,2.4,3.4,4,4.5,4,6,8,10,11]
print([i for i in list if i<5])