

while True:
    choice = int(input(" \n 1. Addition. \n2. Subtraction. \n3. Multiplication. \n 4. Division. \n5. exit"))

    if choice=='1':
        n1 = int(input("Enter the first number : "))
        n2 = int(input("Enter the second number : "))
        print("Addition is : ", n1+n2)

    elif choice=='2':
        n1 = int(input("Enter the first number : "))
        n2 = int(input("Enter the second number : "))
        print("Subtraction is : ", n1-n2)

    elif choice=='3':
        n1 = int(input("Enter the first number : "))
        n2 = int(input("Enter the second number : "))
        print("Multiplication is : " , n1*n2)

    elif choice=='4':
        n1 = int(input("Enter the first number : "))
        n2 = int(input("Enter the second number : "))
        print("Division is : " , n1/n2)

    else:
        print("Invalid choice")