#without slicing and function
str=input("enter string :")
str1=""
for i in str:
    str1=i+str1
    print(str1)
if str==str1:
    print("string is palindrome")
else:
    print("string is not palindrome")

