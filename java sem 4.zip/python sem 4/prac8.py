# prac8
# list=[1,2,3,4,5,6,7,8,9,12,14,16,18]
# print([i for i in list if i%2==0])


# prac8 self1
# a=[ i**2 for i in range(10)  if i%2!=0]
# print(a)


#prac8 self2
# a=[ 2**i for i in range(1,9)]
# print(a)


# #prac8 self3
# a=[]
# print([i for i in range(1,50)if num%1==0 ])