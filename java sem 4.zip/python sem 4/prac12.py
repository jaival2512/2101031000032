l=[{"V":"S001"},{"V":"S002"},{"VI":"S001",},{"VI":"S005"},{"VII":"S005"},{"V":"S009"},{"VIII":"S007"}]
uniquevalues=[]
for dict in l:
    for dict1 in dict.values():
        uniquevalues.append(dict1)
    
print(set(uniquevalues))

