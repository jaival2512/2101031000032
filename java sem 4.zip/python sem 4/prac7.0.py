# using slicing
a=input("enter string :")
if a==a[::-1]:
    print("string is palindrome")
else:
    print("string is not palindrome")
