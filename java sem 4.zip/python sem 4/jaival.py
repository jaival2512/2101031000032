a=int(input("enter value"))
b=int(input("enter value"))
c=int(input("enter value"))
if(a>b) and (a>c):
    print("a is greater")
elif(b>c) and (b>a):
    print("b is greater")
else:
    print("c is greater")
