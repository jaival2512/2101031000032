num=int(input("enter number:"))
if(num%2==0):
    print("the number is even and it is divisible by 2..")
else:
    print("the number is odd")
if(num%4==0):
    print("the number is divisible by 4..")
else:
    print("the number is not divisible by 4..")