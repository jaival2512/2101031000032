# import numpy as np
# x=np.array([[1,2],[3,4]])
# y=np.array([[5,6],[7,8]])

# v=np.array([9,10])
# w=np.array([11,12])
# print(np.dot(v,w),"\n")

# print(np.dot(x,v),"\n")


# # def power(a, b): 
# #     if b == 0:
# #         return 1
# #     else:
# #         return (a*power(a, b-1))

# # if __name__ == '__main__':
# #     a = 2
# #     b = 5

# #     print(power(a,b))

class A:
    def print_A(self):
        