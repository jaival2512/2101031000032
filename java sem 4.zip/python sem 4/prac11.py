a = [5, 10, 15, 20, 25]

def first_last(input_list):
    return [input_list[0], input_list[-1]]

print(first_last(a))