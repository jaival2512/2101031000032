name=input("enter your name")
age=int(input("enter your age"))
result=2023+(100-age)
print(f"{name} will be 100 years in {result}")