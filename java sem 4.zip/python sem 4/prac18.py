#match
import re
s = 'hi jaival here'
match = re.search(r'jaival', s)
print('Start Index:', match.start())
print('End Index:', match.end())

# #findall
# import re
# p = re.compile('[a-e]')
# print(p.findall("jaival here"))

# #split
# from re import split
# print(split('\W+', 'jaival, karan , harsh,murtuza'))