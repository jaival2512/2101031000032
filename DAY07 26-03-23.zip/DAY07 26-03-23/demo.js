function demoInternalAlert() {
    alert('Internal alert');
}
function demoInternalConfirm() {
    if (confirm('Are you sure ?')) {
        alert('Yes')
    }
    else {
        alert('Cancel')
    }
}
function demoInternalPrompt() {
    var fname = prompt('Enter First Name : ');
    var lname = prompt('Enter Last Name : ');
    alert(fname + " " + lname)
}
function bodyBgGreen() {
    document.body.style.backgroundColor = "Green";
}
function divBgGray() {
    document.getElementById('D1').style.backgroundColor = "Gray";
}
function divBgDynamic(){
    document.getElementById('D1').style.backgroundColor = prompt("Enter Color Name");
}
function bodyBgDynamic(){
    document.body.style.backgroundColor =prompt("Enter Color Name") ;
} 
function bodyBgCP1(){
    document.body.style.backgroundColor =document.getElementById('CP1').value ;
}
function divBgCP2(){
    document.getElementById('D1').style.backgroundColor = document.getElementById('CP2').value;
}
function demo1(){
    var a=prompt("enter first number");
    var b=prompt("enter second number");
    if(a>b){
        alert(a+" is greater");
    }
    else{
        alert(b+" is greater");
    }
}
function demo2(){
    var r=prompt("enter radius");
    var area;
    area=3.14*r*r;
    alert("area of circle of radius"+r+"is"+area)
}