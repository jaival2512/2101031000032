<?php
    $username = "root";
    $servername = "localhost";
    $password = "";
    $dbname ="mydb"; 
    $conn = mysqli_connect($servername,$username,$password,$dbname);
    if(!$conn){
        die("connection failed".mysqli_connect_error());
    }
    
    // $sql = "create table info(id int(20) AUTO_INCREMENT PRIMARY KEY , username varchar(50) , password varchar(50))";
    // if(mysqli_query($conn,$sql)){
    //     echo "table created";
    // }
    // else{
    //     echo "error";
    // }
?>