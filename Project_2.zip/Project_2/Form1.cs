﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_2
{
    public partial class Form1 : Form
    {
        int n1;
        int n2;
        int res;
        String op;
        public Form1()
        {
            InitializeComponent();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            // =
            n2 = Convert.ToInt32(textBox1.Text);
            if (op == "+")
            {
                res = (n1 + n2);
                textBox1.Text=Convert.ToString(res);
                n1 = res;
            }
            if (op == "-")
            {
                res = (n1 - n2);
                textBox1.Text = Convert.ToString(res);
                n1 = res;
            }
            if (op == "*")
            {
                res = (n1 * n2);
                textBox1.Text = Convert.ToString(res);
                n1 = res;
            }
            if (op == "/")
            {
                res = (n1 / n2);
                textBox1.Text = Convert.ToString(res);
                n1 = res;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            // +
            n1 = Convert.ToInt32(textBox1.Text);
            textBox1.Text = "";
            op = "+";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            //-
            n1 = Convert.ToInt32(textBox1.Text);
            textBox1.Text = "";
            op = "-";
        }

        private void button13_Click(object sender, EventArgs e)
        {
            //  /
            n1 = Convert.ToInt32(textBox1.Text);
            textBox1.Text = "";
            op = "*";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            // *
            n1 = Convert.ToInt32(textBox1.Text);
            textBox1.Text = "";
            op = "/";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            // 1
            if (textBox1.Text == "0" && textBox1.Text == null)
            {
                textBox1.Text = "1";
            }
            else
            {
                textBox1.Text += "1";
            }

        }

        private void button9_Click(object sender, EventArgs e)
        {

            // 2
            if (textBox1.Text == "0" && textBox1.Text == null)
            {
                textBox1.Text = "2";
            }
            else
            {
                textBox1.Text += "2";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // 3
            if (textBox1.Text == "0" && textBox1.Text == null)
            {
                textBox1.Text = "3";
            }
            else
            {
                textBox1.Text += "3";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // 4
            if (textBox1.Text == "0" && textBox1.Text == null)
            {
                textBox1.Text = "4";
            }
            else
            {
                textBox1.Text += "4";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // 5
            if (textBox1.Text == "0" && textBox1.Text == null)
            {
                textBox1.Text = "5";
            }
            else
            {
                textBox1.Text += "5";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // 6
            if (textBox1.Text == "0" && textBox1.Text == null)
            {
                textBox1.Text = "6";
            }
            else
            {
                textBox1.Text += "6";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // 7
            if (textBox1.Text == "0" && textBox1.Text == null)
            {
                textBox1.Text = "7";
            }
            else
            {
                textBox1.Text += "7";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // 8
            if (textBox1.Text == "0" && textBox1.Text == null)
            {
                textBox1.Text = "8";
            }
            else
            {
                textBox1.Text += "8";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 9
            if (textBox1.Text == "0" && textBox1.Text == null)
            {
                textBox1.Text = "9";
            }
            else
            {
                textBox1.Text += "9";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 0
            if (textBox1.Text == "0" && textBox1.Text == null)
            {
                textBox1.Text = "0";
            }
            else
            {
                textBox1.Text += "0";
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }
    }
}
