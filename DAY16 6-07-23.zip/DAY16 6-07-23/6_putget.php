<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="post.php" id="form1" method="post" name="form1">
        username:
        <input type="text" name="username" id="username"><br><hr>
        password:
        <input type="text" name="password" id="password"><br><hr>
        <input type="submit" name="submit" id="btn"><br>
    </form>
</body>
</html> -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="post.php" id="form1" method="get" name="form1">
        username:
        <input type="text" name="username" id="username"><br><hr>
        password:
        <input type="text" name="password" id="password"><br><hr>
        <input type="submit" name="submit" id="btn"><br>
    </form>
</body>
</html>