<?php
    $username=$_GET['username'];
    $password=$_GET['password'];
    echo $username;
    echo "<br>";
    echo $password;
    echo "<br>";
?>