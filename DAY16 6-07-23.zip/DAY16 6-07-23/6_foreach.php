<?php
    $a=array(1,3,5,7,9);
    print_r($a);

    $sum=0;
    foreach($a as $value){
        $sum=$sum + $value;
    }
    echo "<br>".$sum;
?>