<?php
    $a=250;
    echo $a;
    echo "<br>";
    echo abs($a);
    echo "<br>";
    echo pow(3,3);
    echo "<br>";
    echo min(42,150,11,4);
    echo "<br>";
    $b=25.428;
    echo ceil($b);
    echo "<br>";
?>