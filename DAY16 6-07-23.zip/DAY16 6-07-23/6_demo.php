<?php
    $a=array("xyz","abc","def");
    print_r($a);
    sort($a);
    echo "<br>"."after sorting ". "<br>" ;
    print_r($a);
?>