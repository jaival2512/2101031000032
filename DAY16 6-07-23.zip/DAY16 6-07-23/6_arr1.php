<?php
    $a=array("xyz"=>12,"JHC"=>32,"def"=>34);
    print_r($a);
?>