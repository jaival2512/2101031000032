<?php
    $a=array("jaival","harsh","karan","murtu","keval");
    print_r($a);

    echo "<br>";

    $merge=array_reverse($a);
    print_r($merge);

    echo "<br>";
    echo count($a);
?>